package com.qianfeng.config;


//
//                            _ooOoo_  
//                           o8888888o  
//                           88" . "88  
//                           (| -_- |)  
//                            O\ = /O  
//                        ____/`---'\____  
//                      .   ' \\| |// `.  
//                       / \\||| : |||// \  
//                     / _||||| -:- |||||- \  
//                       | | \\\ - /// | |  
//                     | \_| ''\---/'' | |  
//                      \ .-\__ `-` ___/-. /  
//                   ___`. .' /--.--\ `. . __  
//                ."" '< `.___\_<|>_/___.' >'"".  
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |  
//                 \ \ `-. \_ __\ /__ _/ .-` / /  
//         ======`-.____`-.___\_____/___.-`____.-'======  
//                            `=---='  
//  
//         .............................................  
//                  佛祖镇楼                  BUG辟易  
//          佛曰:  
//                  写字楼里写字间，写字间里程序员；  
//                  程序人员写程序，又拿程序换酒钱。  
//                  酒醒只在网上坐，酒醉还来网下眠；  
//                  酒醉酒醒日复日，网上网下年复年。  
//                  但愿老死电脑间，不愿鞠躬老板前；  
//                  奔驰宝马贵者趣，公交自行程序员。  
//                  别人笑我忒疯癫，我笑自己命太贱；  


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.cache.RedisCacheWriter;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * Created by jackiechan on 2020-03-23 16:26
 * Lettuce 和 Jedis 都是操作 redis 的一个依赖
 *
 * @Author jackiechan
 */
@Configuration
public class RedisConfig extends CachingConfigurerSupport {

    //这个是 key 的生成方式,指的是我们放的 key 可以做具体的区分,不重要
    @Override
    @Bean
    public KeyGenerator keyGenerator() {
//        return new KeyGenerator() {
//            @Override
//            public Object generate(Object target, Method method, Object... params) {
//                StringBuilder stringBuilder = new StringBuilder();
//                stringBuilder.append(target.getClass().getName());
//                stringBuilder.append(method.getName());
//                for (Object param : params) {
//                    stringBuilder.append(params.toString());
//                }
//                return stringBuilder.toString();
//            }
//        };

        return (target,method,params)->{

            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(target.getClass().getName());
            stringBuilder.append(method.getName());
            for (Object param : params) {
                stringBuilder.append(params.toString());
            }
            return stringBuilder.toString();

        };
    }

    //,不重要,指的是我们换粗你的写入方式
    @Bean
    public CacheManager cacheManager(LettuceConnectionFactory connectionFactory) {
        //以锁写入的方式创建我们的写入对象
        RedisCacheWriter writer = RedisCacheWriter.lockingRedisCacheWriter(connectionFactory);
        //创建默认的缓存配置对象
        RedisCacheConfiguration cacheConfiguration = RedisCacheConfiguration.defaultCacheConfig();
        //根据我们的默认配置和写入方式创建缓存的管理器
        RedisCacheManager manager = new RedisCacheManager(writer, cacheConfiguration);

        return manager;
    }


    @Bean//创建我们的模板对象
    public RedisTemplate<String, Object> redisTemplate(LettuceConnectionFactory factory) {

        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(factory);//设置要连接的 redis

        //设置 key 的序列化方式
        StringRedisSerializer stringRedisSerializer = new StringRedisSerializer();//创建一个字符串的序列化方式,所有的数据会被序列为字符串
        redisTemplate.setKeySerializer(stringRedisSerializer);//设置 key 的序列化方式为字符串
        redisTemplate.setHashKeySerializer(stringRedisSerializer);//设置 hash 的 key 序列化方式为 string


        //我们的 value 使用什么方式来进行序列化,因为 value是任意的对象,所以我们使用 json
        Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);//创建一个解析为 json 的序列化对象
        ObjectMapper objectMapper = new ObjectMapper();//因为 jackson 中是使用ObjectMapper来进行序列化的,所以我们需要设置给ObjectMapper
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);//设置所有非 final 修饰的变量都可以被序列化
        jackson2JsonRedisSerializer.setObjectMapper(objectMapper);//指定我们的 objectmapper

        //设置 value 的序列化方式
        redisTemplate.setValueSerializer(jackson2JsonRedisSerializer);//设置值的序列化方式为 json
        redisTemplate.setHashValueSerializer(jackson2JsonRedisSerializer);
        redisTemplate.afterPropertiesSet();

        return redisTemplate;
    }


}
