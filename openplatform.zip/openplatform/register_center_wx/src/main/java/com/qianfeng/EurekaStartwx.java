package com.qianfeng;

/**
 * @Author Wang
 * @Date 2020/3/26
 */
@SpringBootApplication
public class EurekaStartwx {
    public static void main (String[] args){
        SpringApplication.run(EurekaStartwx.class,args);
    }

}
